package com.blendermaster.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blendermaster.app.data.BlenderModule
import com.blendermaster.app.data.BlenderModules

@Composable
fun HomeScreen() {
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 220.dp),
        modifier = Modifier.fillMaxSize().background(BmColors.Background).statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(Modifier.padding(bottom = 8.dp)) {
                Text("BLENDER MASTER", color = BmColors.Accent, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Aprenda, consulte e explore o Blender", color = BmColors.TextMuted, fontSize = 14.sp)
                Text("Base de referência: Blender 5.3 (alpha)", color = BmColors.TextMuted, fontSize = 12.sp)
            }
        }
        items(BlenderModules.all, key = { it.id }) { ModuleCard(it) }
    }
}

@Composable
private fun ModuleCard(m: BlenderModule) {
    Column(
        Modifier.fillMaxWidth().background(BmColors.Panel, RoundedCornerShape(10.dp)).padding(14.dp)
    ) {
        Text(m.title, color = BmColors.Text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        Spacer(Modifier.height(4.dp))
        Text(m.description, color = BmColors.TextMuted, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            if (m.implemented) "Disponível" else "Planejado · Etapa ${m.stage}",
            color = if (m.implemented) BmColors.Accent else BmColors.TextMuted, fontSize = 12.sp,
        )
    }
}
