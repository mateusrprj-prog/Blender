package com.blendermaster.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object BmColors {
    val Background = Color(0xFF1D1D1D)
    val Panel = Color(0xFF303030)
    val PanelHeader = Color(0xFF252525)
    val Accent = Color(0xFFEA7600)   // laranja Blender
    val Text = Color(0xFFE6E6E6)
    val TextMuted = Color(0xFF9A9A9A)
}

private val Scheme = darkColorScheme(
    primary = BmColors.Accent, onPrimary = Color.Black,
    background = BmColors.Background, onBackground = BmColors.Text,
    surface = BmColors.Panel, onSurface = BmColors.Text,
)

@Composable
fun BlenderMasterTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, content = content)
