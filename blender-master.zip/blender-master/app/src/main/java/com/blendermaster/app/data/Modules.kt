package com.blendermaster.app.data

/** Módulos planejados (prompt mestre, seção 6). Apenas [implemented] = true está realmente pronto. */
data class BlenderModule(val id: String, val title: String, val description: String, val stage: Int, val implemented: Boolean = false)

object BlenderModules {
    val all = listOf(
        BlenderModule("explorer", "Explorador do Blender", "Viewport, Outliner, Properties, Timeline, editores e menus", 4),
        BlenderModule("encyclopedia", "Enciclopédia de ferramentas", "Ferramentas com passo a passo, atalhos e dicas", 5),
        BlenderModule("shortcuts", "Atalhos de teclado", "Catálogo pesquisável por categoria", 6),
        BlenderModule("modifiers", "Modificadores", "Finalidade, configurações e combinações", 7),
        BlenderModule("geonodes", "Geometry Nodes", "Conceitos, nós e projetos práticos", 8),
        BlenderModule("shaders", "Materiais e Shaders", "Shader Editor, texturas e iluminação", 9),
        BlenderModule("simulation", "Simulações", "Sistemas de simulação por versão", 10),
        BlenderModule("courses", "Cursos e tutoriais", "Trilhas por nível com progresso", 11),
        BlenderModule("projects", "Projetos práticos", "Projetos guiados", 12),
        BlenderModule("glossary", "Glossário", "Termos de Blender e computação gráfica", 13),
        BlenderModule("assistant", "Assistente de IA", "API configurável e segura", 17),
    )
}
