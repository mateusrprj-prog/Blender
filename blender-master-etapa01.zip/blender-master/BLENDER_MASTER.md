# BLENDER MASTER — Documentação única do projeto

> Único arquivo .md do projeto (regra obrigatória). Última atualização: 2026-11-14 (Sessão 1, Etapa 01).

## 1. Visão geral e objetivo
Aplicativo Android nativo, instalável (APK), para ensinar, consultar e explorar o Blender (enciclopédia, atalhos, modificadores, Geometry Nodes, shaders, simulações, cursos, projetos, glossário, favoritos, progresso, assistente de IA). Desenvolvimento 100% via IA + celular + GitHub + GitHub Actions.

## 2. Tecnologias e justificativas
- Kotlin 1.9.24 + Jetpack Compose (BOM 2024.06.00) + Material 3: UI moderna, nativa, fácil de manter.
- Gradle (Kotlin DSL) + AGP 8.5.2; compileSdk/targetSdk 34, minSdk 26 (ícone adaptativo, ~97% dos aparelhos).
- GitHub Actions: build remoto sem computador. Gradle instalado pelo workflow (setup-gradle 8.7); **wrapper (gradlew) ainda não existe** — ver Próximas tarefas.
- Versões escolhidas por compatibilidade conhecida entre si (Kotlin 1.9.24 ↔ Compose compiler 1.5.14). Não foram verificadas por build real (ver seção 16).

## 3. Arquitetura
Módulo único `app` por enquanto, pacotes: `data/` (modelos e conteúdo), `ui/` (tema, telas). Conteúdo do Blender será dados estruturados (por módulo independente) separados da UI. Modularização Gradle e persistência local (Room/DataStore) serão avaliadas nas Etapas 05 e 14; decisão será registrada aqui antes da mudança.

## 4. Estrutura de pastas
```
.github/workflows/build.yml
app/build.gradle.kts, proguard-rules.pro
app/src/main/AndroidManifest.xml
app/src/main/java/com/blendermaster/app/{MainActivity.kt, data/Modules.kt, ui/Theme.kt, ui/HomeScreen.kt}
app/src/main/res/{values, drawable, mipmap-anydpi-v26}
app/src/test/.../ModulesTest.kt
build.gradle.kts, settings.gradle.kts, gradle.properties, .gitignore, BLENDER_MASTER.md
```

## 5. Identidade visual (inicial)
Implementada na Etapa 01 (`ui/Theme.kt`, `ui/Components.kt`), baseada nos prints do Blender 5.3: fundo #1D1D1D, cabeçalho #303030, corpo de painel #2B2B2B, cabeçalho de painel #3A3A3A, campo #1D1D1D, widget #545454, seleção/slider azul #4772B3, destaque laranja #EA7600, texto #E6E6E6 / secundário #979797. Componentes: BmPanel (painel recolhível com seta e alça ::::), BmTabBar (abas estilo Workspaces), BmPropRow (linha de propriedade), BmBar (slider azul), BmOutlinerRow (linha de Outliner). Cantos 4–6 dp, densidade compacta. Fonte: padrão do sistema (Inter, a fonte do Blender, ainda não embutida).

## 6. Referências de imagens e vídeos enviados
Sessão 1: 12 prints + 1 vídeo (35 s, 720×1280) de **Blender 5.3.0 Alpha rodando no celular (Android)**, tema escuro, horário 22:02–22:04. Observado:
- Splash "Blender 5.3.0 Alpha" com atalhos New File (General, 2D Animation, Sculpting, Storyboarding, VFX, Video Editing), Recent Files, What's New, Donate.
- Workspaces: Layout, Modeling, Sculpting, UV Editing, Texture Paint, Shading, Animation, Rendering, Compositing, Geometry Nodes, Scripting.
- Layout padrão: Viewport (cubo selecionado, laranja), Outliner, Properties, Timeline (frame 58, Start 1, End 250), barra de status com versão 5.3.0 a.
- Scripting (Python Console, Text Editor), Compositing (painel de efeitos: Camera & Lens Effects, Creative, Utilities), menu File (New, Open, Save, Link, Append, Import, Export…), menu Edit (Undo, Adjust Last Operation F9, Menu Search F3, Preferences Ctrl+,).
- Preferences: Interface, Viewport, Lights, Editing, Animation, Get Extensions, Add-ons (Cycles, glTF 2.0, Hydra Storm, Node Wrangler, Pose Library, Rigify, VR Scene Inspection), Themes, Asset Libraries, Input, Navigation, Keymap, System (backend gráfico Vulkan), Save & Load, File Paths.
- Botões de teclado virtuais na tela (Ctrl, Alt, Shift, menu, favorito) e botão flutuante "+".
- Vídeo: abertura do app, controle de rotação de tela, giro para paisagem, splash, uso do Layout.
Uso no design: paleta cinza-escura com acento (azul de seleção e laranja de objeto ativo), cabeçalhos compactos, painéis recolhíveis, ícones lineares. Conteúdo do app deve seguir os nomes reais da interface 5.3 mostrados.

## 7. Funcionalidades planejadas
Módulos 6.1–6.16 do prompt mestre: Início, Explorador, Enciclopédia, Cursos, Busca, Atalhos, Modificadores, Geometry Nodes, Materiais/Shaders, Simulações, Projetos, Glossário, Favoritos/Anotações, Progresso, Configurações, Assistente de IA (chave nunca no repositório).

## 8. Implementadas
- Etapa 00: build via GitHub Actions funcionando; APK instalado e tela inicial confirmada pelo usuário no celular (print 22:32).
- Etapa 01 (código escrito, ainda sem build): tema e componentes estilo Blender; tela inicial com barra de abas (Início + 11 módulos), painel Módulos estilo Outliner, painel Progresso e barra de status. As abas dos módulos mostram apenas placeholder rotulado "Planejado" (conteúdo real nas etapas futuras).

## 9. Em desenvolvimento
Nenhuma.

## 10. Pendentes
Tudo das seções 6.1–6.16 exceto a tela inicial básica.

## 11. Roadmap
Etapa 00 Planejamento ✔ · 01 Identidade visual (código escrito, build pendente) ·  · 02 Navegação · 03 Início · 04 Explorador · 05 Enciclopédia · 06 Atalhos · 07 Modificadores · 08 Geometry Nodes · 09 Shaders · 10 Simulações · 11 Cursos · 12 Projetos · 13 Glossário · 14 Favoritos/Anotações · 15 Progresso · 16 Busca global · 17 Assistente IA · 18 Extras · 19 Testes gerais · 20 Polimento · 21 Build de produção · 22 Evolução contínua.

## 12. Histórico de alterações
- 2026-11-14 (S1): Etapa 01 — tema Blender, componentes, tela inicial redesenhada, versão 0.0.2.
- 2026-11-14 (S1): criação do projeto, workflow, tela inicial, documentação.

## 13. Decisões técnicas
- Kotlin + Compose (preferência do prompt, sem motivo para trocar).
- Workflow instala Gradle em vez de depender de wrapper (não foi possível gerar o wrapper no ambiente da sessão 1).
- minSdk 26 para ícone adaptativo.

## 14. Problemas conhecidos
- Sem gradle wrapper no repositório.
- Etapa 01 ainda não compilada (escrita sem SDK local).
- Fonte Inter não embutida.

## 15. Erros encontrados e soluções
- setup-android@v3 falhava com "Failed to find package 'tools'" → corrigido com `packages: ''` no build.yml.

## 16. Testes realizados e resultados
- Testes automatizados: escritos (`ModulesTest`), **não executados**.
- Etapa 00: compilação via GitHub Actions concluída (APK gerado) após a correção do setup-android. Os testes unitários rodam no workflow; o resultado detalhado não foi enviado à IA.
- Etapa 00 no celular: instalou e abriu; tela inicial conferida por print do usuário (22:32).
- Etapa 01: compilação e teste no celular pendentes.

## 17. Compilar e gerar o APK
Via GitHub: aba Actions → "Build APK" → Run workflow (ou push na `main`) → baixar o artefato `BlenderMaster-debug-apk` → instalar (permitir fontes desconhecidas).

## 18. GitHub Actions
`.github/workflows/build.yml`: Java 17 (temurin), Android SDK, Gradle 8.7, testes unitários, `assembleDebug`, verificação do APK, upload de artefato. Disparos: push na main, PR, manual. Release assinado: Etapa 21 via GitHub Secrets (nada de segredos no repositório).

## 19. Próximas tarefas
1. Usuário envia o zip da Etapa 01 ao repositório; verificar build e print da nova tela.
2. Ajustar visual conforme feedback (fonte Inter, ícones).
3. Adicionar gradle wrapper.
4. Etapa 02: navegação real (rotas por módulo, voltar), substituindo as abas placeholder.

## 20. Contexto para outra IA continuar
Projeto na Etapa 01. O workflow `.github/workflows/build.yml` pega o .zip mais recente do repositório (qualquer nome), extrai e compila. A Etapa 00 compilou e rodou no celular; a Etapa 01 ainda não foi compilada. Primeiro passo: conferir o build do zip mais recente. Regras do prompt mestre valem: um único .md, etapas incrementais, não declarar build/teste sem execução real, sem segredos no repositório, conteúdo do Blender tecnicamente exato e versionado (referência 5.3 alpha; indicar versão por recurso).
