package com.blendermaster.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.blendermaster.app.data.BlenderModule
import com.blendermaster.app.data.BlenderModules

private val iconColors = listOf(
    BmColors.IconMesh, BmColors.IconCamera, BmColors.IconLight, BmColors.IconData, BmColors.IconMat,
)

@Composable
fun HomeScreen() {
    // 0 = Início; 1..n = módulo (ainda placeholders honestos até suas etapas)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val modules = BlenderModules.all
    val tabs = listOf("Início") + modules.map { it.tab }

    Column(Modifier.fillMaxSize().background(BmColors.TopBar).statusBarsPadding().navigationBarsPadding()) {
        TopBar()
        BmTabBar(tabs = tabs, selected = tab, onSelect = { tab = it })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (tab == 0) {
                StartContent(modules, onOpen = { tab = it + 1 })
            } else {
                ModuleContent(modules[tab - 1])
            }
        }
        StatusBar()
    }
}

@Composable
private fun TopBar() {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(22.dp).clip(CircleShape).background(BmColors.Accent), contentAlignment = Alignment.Center) {
            Box(Modifier.size(9.dp).clip(CircleShape).background(BmColors.TopBar))
        }
        Spacer(Modifier.width(10.dp))
        Text("Blender Master", color = BmColors.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text("Blender 5.3", color = BmColors.TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun StartContent(modules: List<BlenderModule>, onOpen: (Int) -> Unit) {
    BmPanel("Bem-vindo") {
        Text("Aprenda, consulte e explore o Blender.", color = BmColors.Text, fontSize = 14.sp)
        Text("Toque em um módulo para ver os detalhes.", color = BmColors.TextMuted, fontSize = 13.sp)
    }
    BmPanel("Módulos") {
        modules.forEachIndexed { i, m ->
            BmOutlinerRow(
                name = m.title,
                iconColor = iconColors[i % iconColors.size],
                tag = "Etapa ${m.stage}",
                selected = false,
                onClick = { onOpen(i) },
            )
        }
    }
    val done = modules.count { it.implemented }
    BmPanel("Progresso do app") {
        BmBar(fraction = done.toFloat() / modules.size, text = "Módulos disponíveis: $done / ${modules.size}")
        Text("Base de referência: Blender 5.3 (alpha)", color = BmColors.TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun ModuleContent(m: BlenderModule) {
    BmPanel(m.title) {
        Text(m.description, color = BmColors.Text, fontSize = 14.sp)
    }
    BmPanel("Propriedades") {
        BmPropRow("Módulo", m.title)
        BmPropRow("Etapa", m.stage.toString())
        BmPropRow("Estado", if (m.implemented) "Disponível" else "Planejado")
    }
    if (!m.implemented) {
        BmPanel("Aviso", initiallyOpen = true) {
            Text("O conteúdo deste módulo ainda não foi implementado. Ele será criado na Etapa ${m.stage}.", color = BmColors.TextMuted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun StatusBar() {
    Row(Modifier.fillMaxWidth().background(BmColors.TopBar).padding(horizontal = 12.dp, vertical = 6.dp)) {
        Text("Etapa 01 · Identidade visual", color = BmColors.TextMuted, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text("0.0.2", color = BmColors.TextMuted, fontSize = 12.sp)
    }
}
