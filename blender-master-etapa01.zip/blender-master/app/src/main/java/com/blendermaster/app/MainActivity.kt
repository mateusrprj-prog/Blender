package com.blendermaster.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.blendermaster.app.ui.BlenderMasterTheme
import com.blendermaster.app.ui.HomeScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BlenderMasterTheme { HomeScreen() } }
    }
}
