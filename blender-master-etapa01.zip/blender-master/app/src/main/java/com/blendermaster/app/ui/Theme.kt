package com.blendermaster.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Cores baseadas nos prints do Blender 5.3 enviados (tema escuro padrão). */
object BmColors {
    val TopBar = Color(0xFF1D1D1D)       // fundo geral / barra superior
    val Header = Color(0xFF303030)       // cabeçalho de editor
    val PanelBody = Color(0xFF2B2B2B)    // corpo de painel
    val PanelHeader = Color(0xFF3A3A3A)  // cabeçalho de painel recolhível
    val Field = Color(0xFF1D1D1D)        // campo de texto/valor
    val Widget = Color(0xFF545454)       // botão/slider
    val TabSelected = Color(0xFF4A4A4A)  // workspace ativo
    val Select = Color(0xFF4772B3)       // azul de seleção/slider preenchido
    val Accent = Color(0xFFEA7600)       // laranja Blender
    val ActiveOutline = Color(0xFFFFAA40)
    val Text = Color(0xFFE6E6E6)
    val TextMuted = Color(0xFF979797)
    // cores de ícones do Outliner
    val IconMesh = Color(0xFFE59A4B)
    val IconCamera = Color(0xFF5FB3A5)
    val IconLight = Color(0xFFE6C44F)
    val IconData = Color(0xFF66B87A)
    val IconMat = Color(0xFFC46B6B)
}

private val Scheme = darkColorScheme(
    primary = BmColors.Accent, onPrimary = Color.Black,
    background = BmColors.TopBar, onBackground = BmColors.Text,
    surface = BmColors.PanelBody, onSurface = BmColors.Text,
)

@Composable
fun BlenderMasterTheme(content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = Scheme, content = content)
