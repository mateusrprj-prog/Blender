package com.blendermaster.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Painel recolhível no estilo do Properties editor (seta + título + alça ::::). */
@Composable
fun BmPanel(
    title: String,
    modifier: Modifier = Modifier,
    initiallyOpen: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    var open by rememberSaveable { mutableStateOf(initiallyOpen) }
    Column(modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(BmColors.PanelBody)) {
        Row(
            Modifier.fillMaxWidth().background(BmColors.PanelHeader)
                .clickable { open = !open }.padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(if (open) "▾" else "▸", color = BmColors.Text, fontSize = 14.sp)
            Spacer(Modifier.width(8.dp))
            Text(title, color = BmColors.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text("::::", color = BmColors.TextMuted, fontSize = 12.sp)
        }
        if (open) {
            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
        }
    }
}

/** Barra de abas no estilo dos Workspaces (Layout, Modeling, Sculpting...). */
@Composable
fun BmTabBar(tabs: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(BmColors.TopBar)
            .horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        tabs.forEachIndexed { i, t ->
            val sel = i == selected
            Text(
                t,
                color = if (sel) Color.White else BmColors.TextMuted,
                fontSize = 13.sp,
                maxLines = 1,
                modifier = Modifier.clip(RoundedCornerShape(6.dp))
                    .background(if (sel) BmColors.TabSelected else Color.Transparent)
                    .clickable { onSelect(i) }.padding(horizontal = 12.dp, vertical = 7.dp),
            )
        }
    }
}

/** Linha de propriedade: rótulo à esquerda (alinhado à direita) e campo escuro à direita. */
@Composable
fun BmPropRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = BmColors.TextMuted, fontSize = 13.sp, textAlign = TextAlign.End, modifier = Modifier.weight(0.38f).padding(end = 10.dp))
        Text(
            value, color = BmColors.Text, fontSize = 13.sp,
            modifier = Modifier.weight(0.62f).clip(RoundedCornerShape(4.dp)).background(BmColors.Field).padding(horizontal = 10.dp, vertical = 7.dp),
        )
    }
}

/** Barra de valor no estilo dos sliders do Blender (preenchimento azul). */
@Composable
fun BmBar(fraction: Float, text: String) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(BmColors.Widget)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).height(30.dp).background(BmColors.Select))
        Text(text, color = Color.White, fontSize = 13.sp, modifier = Modifier.align(Alignment.Center).padding(vertical = 6.dp))
    }
}

/** Linha estilo Outliner: seta, ícone colorido, nome, etiqueta à direita. */
@Composable
fun BmOutlinerRow(name: String, iconColor: Color, tag: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp))
            .background(if (selected) BmColors.Select else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("▸", color = BmColors.TextMuted, fontSize = 12.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.size(12.dp).clip(CircleShape).background(iconColor))
        Spacer(Modifier.width(10.dp))
        Text(name, color = BmColors.Text, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 1)
        Text(tag, color = if (selected) Color.White else BmColors.TextMuted, fontSize = 12.sp)
    }
}
