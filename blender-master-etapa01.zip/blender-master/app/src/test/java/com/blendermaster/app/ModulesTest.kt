package com.blendermaster.app

import com.blendermaster.app.data.BlenderModules
import org.junit.Assert.assertEquals
import org.junit.Test

class ModulesTest {
    @Test fun idsAreUnique() = assertEquals(BlenderModules.all.size, BlenderModules.all.map { it.id }.toSet().size)
    @Test fun nothingFakeImplemented() = assert(BlenderModules.all.none { it.implemented })
}
